#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <cctype>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <map>
#include <istream>
#include "tokens.h"
#include "getNextToken.h"
using namespace std;

int main(int argc, char *argv[])
{   
    int identCount = 0;
    int sconstCount = 0;
    vector <string> tokenList;
    bool vFlag = false;
    bool allFlag = false;
    bool sumFlag = false;
    bool filePresent=false;
    ifstream inFile;
    string stringmode="";
    
    for(int i=1; i<argc; i++){
        
        string arg(argv[i]);
        if(arg[0]=='-')
        {
            if(!arg.compare("-v")){
                vFlag = true;
                continue;
            }
            else if(!arg.compare("-sum")){
                sumFlag = true;
                continue;
            }
            else if(!arg.compare("-allids")){
                allFlag = true;
                continue;
            }
            else{
                cout<<"INVALID FLAG "<<arg<<endl;
                return 0;
            }
       }
       else{
           if(filePresent){
               cout<<"TOO MANY FILE NAMES"<<endl;
               return 0;
           }
           
           filePresent=true;
          
           inFile.open(argv[i]);
           
           if(!inFile){
               cout<<"UNABLE TO OPEN "<<arg<<endl;
               return 0;
           }
       }
    }
    
    
    //Token(TokenType tt, string lexeme, int line)
    
    Token tok;
    int lineNumber=0;
    
    string tokenTypes[]=                       {"PRINT","IF","THEN","TRUE","FALSE","IDENT","ICONST","SCONST","PLUS","MINUS","STAR","SLASH","ASSIGN","EQ","NEQ","LT","LEQ","GT","GEQ","LOGICAND","LOGICOR","LPAREN","RPAREN","SC","ERR","DONE"};
    
    if(filePresent)
    {
        if(vFlag)
        {
            istream&  s   = inFile;
            while( (tok = getNextToken(&s, &lineNumber)) != DONE && tok != ERR )
            {
                if (tok.GetTokenType()==SCONST)
                {
                    cout<<tokenTypes[tok.GetTokenType()]<<"("<<tok.GetLexeme().substr(1,tok.GetLexeme().length()-2)<<")"<<endl;
                    sconstCount++;
                    continue;
                }
                
                else if (tok.GetTokenType()==IDENT)
                {
                    tokenList.push_back(tok.GetLexeme());
                    
                    cout<<tokenTypes[tok.GetTokenType()]<<"("<<tok.GetLexeme()<<")"<<endl;
                    identCount++;
                    continue;
                }
                
                else if (tok.GetTokenType()==ICONST)
                {
                    cout<<tokenTypes[tok.GetTokenType()]<<"("<<tok.GetLexeme().substr(1,tok.GetLexeme().length()-2)<<")"<<endl;
                    continue;
                }
                
                
            
                else if(tok.GetTokenType()==ERR)
                {
                cout<<"Error on line "<<lineNumber<<" ("<<tok.GetLexeme()<<")"<<endl;
                }
                cout<<tokenTypes[tok.GetTokenType()]<<endl;
            }
        }
        else
        {
            istream&  s   = inFile;
            while( (tok = getNextToken(&s,&lineNumber)) != DONE && tok != ERR )
            {
    
             if (tok.GetTokenType()==SCONST)
                    {
                        sconstCount++;
                        continue;
                    }

                    else if (tok.GetTokenType()==IDENT)
                    {
                        tokenList.push_back(tok.GetLexeme());
                         
                        identCount++;
                        continue;
                    }
                    else if (tok.GetTokenType()==ICONST)
                    {
                        continue;
                    }
                }
                if(tok.GetTokenType()==ERR)
                {
                    cout<<"Error on line "<<lineNumber<<" ("<<tok.GetLexeme()<<")"<<endl;
                } 
            }
        
      
       if (allFlag)
       {
           
           for (int i = 0;i<tokenList.size();i++)
           {
               for (int j = 0;i<tokenList.size();i++)
               {
                   if(tokenList[i] < tokenList[j] ||  tokenList[i] > tokenList[j])
                   {
                       string k =  tokenList[i];
                       cout<< k <<endl;
                       tokenList[i] = tokenList[j];
                       tokenList[j] = k;
                       i = j;
                   }
               
               }
           }
           cout<<"IDENTIFIERS: ";
           
           for (int i = 0;i<tokenList.size();i++)
           {
              
              
               if(i != tokenList.size()-1)
               {
                   cout<<", "<<endl;
               }
           }   
       }
         if (sumFlag)
       {
         cout<<"sum test"<<endl;
       }
        
        
        
        
    }  
    }  
