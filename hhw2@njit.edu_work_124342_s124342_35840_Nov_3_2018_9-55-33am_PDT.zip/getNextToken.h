
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <cctype>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <map>
#include <istream>
#include "tokens.h"




Token getNextToken(istream *in, int *linenum){
    
    enum LexState { BEGIN, INSTRING, INIDENT,INICONST,KEYWORD};
    
    LexState lexstate = BEGIN;

    string lexeme;
    char ch;
    
    while(in->get(ch)) {
        
        if( ch == '\n' && lexstate!=INSTRING ) {
            (*linenum)++;
        }
        
        string check(1, ch);
        
        if(lexstate!=INSTRING && check=="#"){
            (*linenum)++;
            continue;
        }
        
        
        switch( lexstate ) 
        {
            case BEGIN:
            {
                if(isspace(ch))
                {
                    continue;
                }
                if(!isalpha(ch))
                {
                    lexeme = ch;
                    string op(1, ch);
                    if(op=="+")
                    {
                        lexeme=ch;
                        Token ret(PLUS, "+", *linenum);
                        return ret;
                    }
                    else if(op=="-")
                    {
                        lexeme=ch;
                        Token ret(MINUS, "-", *linenum);
                        return ret;
                    }
                    else if(op=="*")
                    {
                        lexeme=ch;
                        Token ret(STAR, "*", *linenum);
                        return ret;
                    }
                    else if(op=="/"){
                        lexeme=ch;
                        Token ret(SLASH, "/", *linenum);
                        return ret;
                    }
                    else if(op=="("){
                        lexeme=ch;
                        Token ret(LPAREN, "(", *linenum);
                        return ret;
                    }
                    else if(op==")"){
                        lexeme=ch;
                        Token ret(RPAREN, ")", *linenum);
                        return ret;
                    }
                    else if(op==";"){
                        lexeme=ch;
                        Token ret(SC, ";", *linenum);
                        return ret;
                    }
                    else if(op=="="){
                        lexeme=ch;
                        in->get(ch);
                        op=ch;
                        if(op=="="){
                            Token ret(EQ, "==", *linenum);
                            return ret;
                        }
                        else{
                            Token ret(ASSIGN, "=", *linenum);
                            return ret;
                        }
                    }
                    else if(op==">"){
                        lexeme=ch;
                        in->get(ch);
                        op=ch;
                        if(op=="="){
                            Token ret(GEQ, ">=", *linenum);
                            return ret;
                        }
                        else{
                            Token ret(GT, ">", *linenum);
                            return ret;
                        }
                    }
                    else if(op=="<"){
                        lexeme=ch;
                        in->get(ch);
                        op=ch;
                        if(op=="="){
                            Token ret(LEQ, "<=", *linenum);
                            return ret;
                        }
                        else{
                            Token ret(LT, "<", *linenum);
                            return ret;
                        }
                    }
                    else if(op=="!"){
                        lexeme=ch;
                        in->get(ch);
                        op=ch;
                        if(op=="="){
                            Token ret(NEQ, "!=", *linenum);
                            return ret;
                        }
                    }
                    else if(op=="&"){
                        lexeme=ch;
                        in->get(ch);
                        op=ch;
                        if(op=="&"){
                            Token ret(LOGICAND, "&&", *linenum);
                            return ret;
                        }
                    }    
                    else if(op=="|")
                    {
                        lexeme=ch;
                        in->get(ch);
                        op=ch;
                        if(op=="|")
                        {
                            Token ret(LOGICOR, "||", *linenum);
                            return ret;
                        }
                    } 
                }//operator check
                        
                
                if( isalpha(ch) || ch =='_') {
                    string id(1,ch);
                    lexeme +=id;
                    lexstate = INIDENT;
                }
                
                if(isdigit(ch))
                {
                    string op(1,ch);
                    lexeme +=op;
                    if(ch == '0')
                    {
                        Token ret(ERR,lexeme,*linenum);
                    }
                    else
                    {
                        lexstate = INICONST;
                        continue;
                    }
                }
                
                if( ch == '"' ) 
                {
                    lexstate = INSTRING;
                    lexeme="\"";
                    continue;
                }
            }
                
            case INSTRING:
                {  
                string character(1,ch);
                    
                if(!character.compare("\n"))
                {
                    lexeme+=character;
                    Token ret(ERR, lexeme, *linenum);
                    (*linenum)++;
                    return ret;
                }
                    
                else if(!character.compare("\"")){
                    lexeme+=character;
                    Token ret(SCONST, lexeme, *linenum);
                    return ret;
                }
                    
                else{
                    lexeme+=character;
                    continue;
                }
                Token ret(SCONST, lexeme, *linenum);
                return ret;
                }
                
           case INIDENT:
                {
                string s (1,ch);
               if (isspace(ch))
               {
                  if (!lexeme.compare("print")|| !lexeme.compare("if")|| !lexeme.compare("true")|| !lexeme.compare("false") || !lexeme.compare("then"))
                      lexstate = KEYWORD;
                      continue;
                  Token ret(IDENT,lexeme,*linenum);
                   return ret;
                   
               }
               else if(isalpha(ch) || isdigit(ch) || ch == '_')
               {
                   string s (1,ch);
                   lexeme+= s;
                   continue;
                   
               }
                else
                {
                    Token ret(ERR,lexeme,*linenum);
                   return ret;
                }
                
                }
            case KEYWORD:
                {
                    if(!lexeme.compare("print"))
                    {
                    Token ret(PRINT,lexeme,*linenum);
                    return ret;
                    }
                   else if(!lexeme.compare("if"))
                    {
                    Token ret(IF,lexeme,*linenum);
                    return ret;
                    }
                   else if(!lexeme.compare("true"))
                    {
                    Token ret(TRUE,lexeme,*linenum);
                    return ret;
                    }
                    else if(!lexeme.compare("false"))
                    {
                    Token ret(FALSE,lexeme,*linenum);
                    return ret;
                    }
                    else if(!lexeme.compare("then"))
                    {
                    Token ret(THEN,lexeme,*linenum);
                    return ret;
                    }
                    else
                    {
                    Token ret(ERR,lexeme,*linenum);
                    return ret;
                    }
                }
             case INICONST:
                {
                   
                    if(!isdigit(ch))
                    {
                        if(isspace(ch))
                        {
                             Token ret(ICONST, lexeme, *linenum);
                             return ret;
                        }
                    string op(1,ch);
                    lexeme+=op;
                    Token ret(ERR,lexeme,*linenum);
                    return ret;
                    }
                    else
                    {
                    string op(1,ch);
                    lexeme+=op;
                    continue;
                    }
                }
             
        }//SWITCH STATEMENT
    }
    Token ret(DONE, "endOfFile", *linenum);
    return ret;    
}